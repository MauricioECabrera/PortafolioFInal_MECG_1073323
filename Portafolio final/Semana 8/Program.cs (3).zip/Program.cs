﻿Console.WriteLine("MECG - 1073323 - DJUC - 11219823");
Console.WriteLine("Mauricio Cabrera - Diego Urbina");
int opcion;
do
{
    // Menu

    Console.WriteLine("Menu");
    Console.WriteLine("1. Ahorro anual");
    Console.WriteLine("2. Ventas");
    Console.WriteLine("3. Salir del programa");
    Console.Write("Ingrese la opcion que desee: ");
    opcion = int.Parse(Console.ReadLine());

    switch (opcion)
    {
        // Ejercicio 1

        case 1:
            Console.Clear();
            double totalAhorrado = 0.0;

            for (int mes = 1; mes <= 12; mes++)
            {
                Console.Write("Ingrese el ahorro del mes " + mes + ": ");
                double ahorroMensual = double.Parse(Console.ReadLine());

                totalAhorrado += ahorroMensual;

                Console.WriteLine("Ahorro acumulado hasta el mes " + mes + ": " + totalAhorrado.ToString("C"));
            }
            Console.WriteLine("Total ahorrado en el año: " + totalAhorrado.ToString("C"));
            Console.ReadKey();
            Console.Clear();
            break;

        // Ejercicio 2

        case 2:
            Console.Clear();
            int ventas = 0;
            int mayores1300 = 0;
            int mayores300 = 0;
            int menoresIgual300 = 0;
            double montoTotal = 0;
            double montoMayor1300 = 0;
            double montoEntre300y1300 = 0;
            double montoMenorIgual300 = 0;

            Console.WriteLine("Ingrese la cantidad de ventas realizadas: ");
            ventas = int.Parse(Console.ReadLine());

            for (int i = 0; i < ventas; i++)
            {
                Console.WriteLine("Ingrese el monto de la venta #" + (i + 1) + ": ");
                double montoVenta = double.Parse(Console.ReadLine());
                montoTotal += montoVenta;

                if (montoVenta > 1300)
                {
                    mayores1300++;
                    montoMayor1300 += montoVenta;
                }
                else if (montoVenta > 300)
                {
                    mayores300++;
                    montoEntre300y1300 += montoVenta;
                }
                else
                {
                    menoresIgual300++;
                    montoMenorIgual300 += montoVenta;
                }
            }

            Console.WriteLine("\nVentas mayores a Q1300: " + mayores1300 + " por un total de Q" + montoMayor1300);
            Console.WriteLine("Ventas mayores a Q300 pero menores o iguales a Q1300: " + mayores300 + " por un total de Q" + montoEntre300y1300);
            Console.WriteLine("Ventas menores o iguales a Q300: " + menoresIgual300 + " por un total de Q" + montoMenorIgual300);
            Console.WriteLine("Monto total de ventas: Q" + montoTotal);
            Console.ReadKey();
            Console.Clear();
            break;
            
        case 3:
            Console.Clear();
            Console.WriteLine("Salio del programa");

            Console.ReadKey();
            Console.Clear();
            break;
        default:
            Console.Clear();
            Console.WriteLine("Opción no valida");
            Console.ReadKey();
            Console.Clear();
            break;
    }

} while (opcion != 3);