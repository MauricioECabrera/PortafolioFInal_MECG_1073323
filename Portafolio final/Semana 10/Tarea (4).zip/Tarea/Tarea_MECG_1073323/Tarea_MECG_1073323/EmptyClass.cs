﻿using System;

public class Pelicula
{
    private string nombre;
    private int duracion;
    private string genero;
    private int año;
    private double calificacion;

    // Constructor
    public Pelicula(string nombre, int duracion, string genero, int anio)
    {
        this.nombre = nombre;
        this.duracion = duracion;
        this.genero = genero;
        this.año = anio;
    }

    // Método que imprime la información de la película
    public void ImprimirInformacion()
    {
        Console.WriteLine("Nombre: " + nombre);
        Console.WriteLine("Duración: " + duracion + " minutos");
        Console.WriteLine("Género: " + genero);
        Console.WriteLine("Año: " + año);
        Console.WriteLine("Calificación: " + calificacion);
    }

    // Método booleano que devuelve si la película es épica
    public bool esPeliculaEpica()
    {
        if (duracion >= 180)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    // Método que devuelve la valoración de la película
    public string ObtenerValoracion()
    {
        if (calificacion <= 2)
        {
            return "Muy mala";
        }
        else if (calificacion > 2 && calificacion <= 5)
        {
            return "Mala";
        }
        else if (calificacion > 5 && calificacion <= 7)
        {
            return "Regular";
        }
        else if (calificacion > 7 && calificacion <= 8)
        {
            return "Buena";
        }
        else if (calificacion > 8 && calificacion <= 10)
        {
            return "Excelente";
        }
        else
        {
            return "Calificación inválida";
        }
    }

    // Método booleano que devuelve si la película es similar a otra
    public bool esSimilar(Pelicula otraPelicula)
    {
        if (genero == otraPelicula.genero && calificacion == otraPelicula.calificacion)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    // Propiedades para acceder y modificar la calificación de la película
    public double Calificacion
    {
        get { return calificacion; }
        set { calificacion = value; }
    }
}

class Program
{
    static void Main(string[] args)
    {
        Pelicula pelicula1 = new Pelicula("Gandhi", 191, "Drama", 1982);
        pelicula1.Calificacion = 8.1;

        Pelicula pelicula2 = new Pelicula("Thor", 115, "Acción", 2011);
        pelicula2.Calificacion = 7.0;

        Console.WriteLine("Información de la película 1:");
        pelicula1.ImprimirInformacion();
        Console.WriteLine("Valoración: " + pelicula1.ObtenerValoracion());
        Console.WriteLine("¿Es película épica? " + pelicula1.esPeliculaEpica());

        Console.WriteLine("\nInformación de la película 2:");
        pelicula2.ImprimirInformacion();
        Console.WriteLine("Valoración: " + pelicula2.ObtenerValoracion());
        Console.WriteLine("¿Es película épica? " + pelicula2.esPeliculaEpica());

        Console.WriteLine("No Son similares las peliculas 1 y 2");
    }
}