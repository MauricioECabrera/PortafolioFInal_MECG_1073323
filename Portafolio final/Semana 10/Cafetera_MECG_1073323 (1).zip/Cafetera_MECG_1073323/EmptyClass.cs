﻿using Internal;

public class Cafetera
{
    public string codeinventario;
    public int capacidadTazas;
    public int tazasDisponibles;
    public int tazasServidas;

    public Cafetera(string codigo, int capacidad)
    {
        codeinventario = codigo;
        capacidadTazas = capacidad;
        tazasDisponibles = 0;
        tazasServidas = 0;
    }

    public void HacerCafe()
    {
        tazasDisponibles = capacidadTazas;
        tazasServidas = 0;
    }

    public bool ServirTaza(int cantidad)
    {
        if (cantidad <= tazasDisponibles)
        {
            tazasDisponibles -= cantidad;
            tazasServidas += cantidad;
            return true;
        }
        else
        {
            return false;
        }
    }

    public double ObtenerPorcentajeDisponibilidad()
    {
        return ((double)tazasDisponibles / (double)capacidadTazas) * 100.0;
    }

    public void MostrarEstado()
    {
        Console.WriteLine("Código de inventario: " + codeinventario);
        Console.WriteLine("Capacidad en cantidad de tazas: " + capacidadTazas);
        Console.WriteLine("Porcentaje de disponibilidad: " + ObtenerPorcentajeDisponibilidad() + "%");
        Console.WriteLine("Tazas servidas: " + tazasServidas);
    }
}