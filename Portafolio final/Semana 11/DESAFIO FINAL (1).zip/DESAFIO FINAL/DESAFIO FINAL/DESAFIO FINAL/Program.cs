﻿

internal class Program
{
    private static void Mainx(string[] args)
    {
        Libro libro = new Libro(1, "Don QUijote de la Mancha", 1967);
        libro.MostrarLibro();
        Console.WriteLine("---------------");
        libro.Leer(150);
        libro.MostrarLibro();
        Console.WriteLine("---------------");
        libro.Leer(652);
        libro.MostrarLibro();
    }
}